from django.views.generic.edit import CreateView
from django.views.generic.list import ListView
from .models import TodoApp

class TodoAppCreative(CreateView):
  model = TodoApp
  fields = [
    "title",
    "description"
  ]
  template_name = 'Home.html'

class TodoAppListView(ListView):
  model = TodoApp
  template_name = 'List.html'

# Create your views here.
